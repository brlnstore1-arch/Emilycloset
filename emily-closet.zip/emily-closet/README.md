# 👗 Emily Closet

App de gerenciamento de vendas e clientes para o negócio de moda da Emily.

## ✅ Funcionalidades
- Login seguro com conta Google
- Cadastro de clientes
- Registro de vendas (à vista, a prazo, cartão)
- Controle de parcelas e cobranças
- Fluxo de caixa e despesas
- Catálogo de produtos
- Dashboard com alertas de parcelas vencidas
- Dados salvos na nuvem (Firebase) — nunca perde nada!

## 📱 Como instalar no iPhone
1. Acesse o link do app pelo Safari
2. Toque no ícone de compartilhar (quadrado com seta)
3. Selecione "Adicionar à Tela de Início"
4. Pronto! O ícone aparece na tela como um app normal

## 🔗 Link do app
https://SEU-USUARIO.github.io/emily-closet/
